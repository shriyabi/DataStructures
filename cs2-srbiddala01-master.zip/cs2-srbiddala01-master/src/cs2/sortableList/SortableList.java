// I did Gnome Sort... refer to lines 65-93 w/ description.

package cs2.sortableList;

import java.util.ArrayList;

public class SortableList<E extends Comparable<E>> extends ArrayList<E> {

    // SELECTION SORT
    public void selectionSort() {
        for (int i = 0; i < this.size() - 1; i++) {
            swap(i, findMinimum(i));
        }
    }

    //BUBBLE SORT
    public void bubbleSort() {
        //I re-did this portion to be more efficient (as per your comment on IC)
        for(int i = 0; i < this.size(); i++){
            int counter = 0;
            boolean exchangeMade = true;
            while(counter < i - 1 && exchangeMade){
                exchangeMade = false;
                counter++;
                for(int a = 0; a < i - counter; a++){
                    if(this.get(a).compareTo(this.get(a + 1)) > 0){
                        swap(a, a + 1);
                        exchangeMade = true;
                    }
                }
            }
        }
    }

    //INSERTION SORT
    public void insertionSort() {
        for (int k = 0; k < this.size(); k++) {
            E val = this.get(k);
            int j = k - 1;
            while (j >= 0 && val.compareTo(this.get(j)) < 0) {
                this.set(j + 1, this.get(j));
                j--;
            }
            this.set(j + 1, val);
        }
    }

    //MERGE SORT
    public void mergeSort() {
        SortableList<E> firstHalf = new SortableList<>();
        SortableList<E> secondHalf = new SortableList<>();
        if (this.size() == 0 || this.size() == 1) {
            return;
        }
        int middle = this.size() / 2;
        for (int i = 0; i < middle; i++) {
            firstHalf.add(this.get(i));
        }
        for (int i = middle; i < this.size(); i++) {
            secondHalf.add(this.get(i));
        }
        this.clear();
        firstHalf.mergeSort();
        secondHalf.mergeSort();
        merge(firstHalf, secondHalf);
    }

    //GNOME SORT
    /* Sorting Method: Gnome Sort
       Source: https://www.geeksforgeeks.org/gnome-sort-a-stupid-one/
     */
    public void gnomeSort() {
        int index = 0;
        while (index < this.size()) {
            if (index == 0) {
                index++;
            } else if (this.get(index).compareTo(this.get(index - 1)) >= 0) {
                index++;
            } else {
                swap(index, index - 1);
                index--;
            }
        }
    }
    // Brief Description: GnomeSort starts at the first element of the array;
    // it prevents an exception from being thrown by ensuring
    // that when the element is at index 0 the index is bumped
    // up by 1 as the first element is definitely sorted. If
    // the element at the index is greater than or equal to
    // the element before it, it makes sure that the index is
    // bumped up by one as those two elements are already sorted.
    // If not, it swaps those two elements so the current element
    // can be before the element that was originally behind it as
    // it is smaller. The index is then decremented to check
    // whether the element that had just been swapped to a greater
    // index is smaller or greater to the element next to it.

    public int findMinimum(int first) {
        E min = this.get(first);
        int minIndex = first;
        for (int i = first + 1; i < this.size(); i++) {
            if (this.get(i).compareTo(min) < 0) {
                min = this.get(i);
                minIndex = i;
            }
        }
        return minIndex;
    }

    public void swap(int first, int second) {
        E placeholder = this.get(first);
        this.set(first, this.get(second));
        this.set(second, placeholder);
    }

    public void merge(SortableList<E> first, SortableList<E> second) {
        int firstIndex = 0;
        int secondIndex = 0;
        while (firstIndex != first.size() && secondIndex != second.size()) {
            if (first.get(firstIndex).compareTo(second.get(secondIndex)) < 0) {
                this.add(first.get(firstIndex));
                firstIndex++;
            } else {
                this.add(second.get(secondIndex));
                secondIndex++;
            }
        }
        if (firstIndex == first.size()) {
            for (int i = secondIndex; i < second.size(); i++) {
                this.add(second.get(i));
            }
        } else {
            for (int i = firstIndex; i < first.size(); i++) {
                this.add(first.get(i));
            }
        }
    }
}


