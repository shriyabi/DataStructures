package cs2.sortableList;

public class Runner {
    public static void main (String[] args) {
        SortableList<Integer> list1 = new SortableList<>();

        for (int i=0; i<10; i++) {
            list1.add((int)(Math.random()*100));
        }

        SortableList<Integer> list2 = (SortableList<Integer>)list1.clone();
        SortableList<Integer> list3 = (SortableList<Integer>)list1.clone();
        SortableList<Integer> list4 = (SortableList<Integer>)list1.clone();
        SortableList<Integer> list5 = (SortableList<Integer>)list1.clone();

        System.out.println("Selection Sort: ");
        System.out.println(list1);
        list1.selectionSort();
        System.out.println(list1 +"\n");

        System.out.println("Bubble Sort: ");
        System.out.println(list2);
        list2.bubbleSort();
        System.out.println(list2 + "\n");

        System.out.println("Insertion Sort: ");
        System.out.println(list3);
        list3.insertionSort();
        System.out.println(list3 + "\n");

        System.out.println("Merge Sort: ");
        System.out.println(list4);
        list4.mergeSort();
        System.out.println(list4 + "\n");

        System.out.println("Gnome Sort: ");
        System.out.println(list5);
        list5.gnomeSort();
        System.out.println(list5 + "\n");
    }
}
