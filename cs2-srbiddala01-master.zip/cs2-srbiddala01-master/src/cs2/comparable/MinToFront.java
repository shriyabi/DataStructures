package cs2.comparable;

import java.util.ArrayList;
import java.util.Arrays;

public class MinToFront {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList(Arrays.asList("the", "quick", "brown", "fox"));
        System.out.println(list);
        minToFront(list);
        System.out.println(list);
    }

    public static void minToFront(ArrayList<String> arr){
        String min = arr.get(0);
        for(int i = 1; i < arr.size(); i++){
            if (arr.get(i).compareTo(min) < 0){
                min = arr.get(i);
            }
            arr.remove(arr.indexOf(min));
            arr.add(0, min);
        }
    }
}
