package cs2.comparable;

import java.util.Scanner;

public class Strings {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Enter two strings: ");
        String response = reader.next();
        String response2 = reader.next();

        System.out.println(isLonger(response, response2));
        System.out.println(alphabetize(response, response2));

    }

    public static String isLonger(String s1, String s2){
        if(s1.length() > s2.length()){
           return "Your word " + s1 + " is longer.";
        } else if (s1.length() == s2.length()){
            return "Both are the same length";
        }
        else {
            return "Your word " + s2 + " is longer.";
        }
    }

    public static String alphabetize(String s1, String s2){
        if(s1.compareTo(s2) < 0){
            return (s1 + " comes first");
        } else if(s1.compareTo(s2) > 0){
            return (s2 + " comes first");
        } else {
            return("You entered the same word twice.");
        }
    }
}
