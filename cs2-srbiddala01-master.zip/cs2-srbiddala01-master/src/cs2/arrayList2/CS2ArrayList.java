package cs2.arrayList2;

import cs2.CS2List;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class CS2ArrayList<E> implements CS2List<E>, Iterable<E> {
    public void setMyList(E[] myList) {
        this.myList = myList;
    }

    //Instance variables
    private E myList[];

    private int mySize;

    //Constructor
    public CS2ArrayList() {
        myList = (E[]) (new Object[20]);
        mySize = 0;
    }

    //Public Methods
    @Override
    public int size() {
        return mySize;
    }

    @Override
    public boolean add(E obj) {
        mySize++;
        if (mySize >= myList.length) {
            this.expand();
        }
        myList[mySize - 1] = obj;
        return true;
    }

    @Override
    public void add(int index, E obj) {
        if (index < 0) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        mySize++;
        if (mySize >= myList.length || index > myList.length) {
            this.expand();
        }
        for (int i = mySize; i > index; i--) {
            myList[i] = myList[i - 1];
        }
        myList[index] = obj;
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= mySize) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        return myList[index];
    }

    @Override
    public E set(int index, E obj) {
        if (index < 0 || index >= mySize) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        E temp = myList[index];
        myList[index] = obj;
        return temp;
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= mySize) {
            throw new RuntimeException("Index " + index + " is not in length");
        }
        E temp = myList[index];
        for (int i = index; i < myList.length - 1; i++) {
            myList[i] = myList[i + 1];
        }
        mySize--;
        return temp;
    }

    private void expand() {
        if (mySize >= myList.length) {
            E[] biggerArray = (E[]) (new Object[(int) (myList.length * 1.5)]);
            for (int i = 0; i < myList.length; i++) {
                biggerArray[i] = myList[i];
            }
            setMyList(biggerArray);
        }
    }

    public String toString() {
        String info = "";
        if (mySize == 0) {
            info = "";
        } else {
            for (int i = 0; i < mySize; i++) {
                info = info + " [" + i + "]: " + myList[i];
            }
        }
        return "{" + info + "}";
    }

    @Override
    public Iterator<E> iterator() {
        return new CS2Iterator();
    }

    public ListIterator<E> listIterator() {
        return new CS2Iterator();
    }

    private class CS2Iterator implements ListIterator<E> {
        private int next = 0;
        private int last = -1;
        private boolean canRemove = false;
        private boolean canSet = false;
        private boolean canAdd = false;

        /**
         * Checks the next element to ensure that the iterator isn't at the end of the array
         *
         * @return Returns true if the next element exists and isn't at the end of the array; else it returns false
         */
        @Override
        public boolean hasNext() {
            if (mySize > 1 && next < mySize) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * Moves onto the next element if there is an element that doesn't expand past th length of the array/exists, subsequently providing the next element and iterating the index; throws an exception if there isn't a next value
         *
         * @return Returns the next element
         */
        @Override
        public E next() {
            canRemove = true;
            canSet = true;
            canAdd = true;
            if (hasNext()) {
                return myList[next++];
            } else {
                throw new IllegalStateException("There is no next value");
            }
        }

        /**
         * Checks if there is a previous index
         *
         * @return Returns ture if there is a previous index
         */
        @Override
        public boolean hasPrevious() {
            if (next > 0 && mySize > 1) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * Provides the element at the previous index, if there is one; throws an exception if there isn't a value
         *
         * @return Returns the element at the previous index, given there is one
         */
        @Override // bug here with previous index... it doesn't loop it just stops
        public E previous() {
            canRemove = true;
            canSet = true;
            canAdd = true;
            if (hasPrevious()) {
                next--;
                return myList[next];
            } else {
                throw new IllegalStateException("There is no next value");
            }
            //why is it returning null in beginning?; expand shouldn't work
        }

        /**
         * Provides the next index
         *
         * @return Returns the next index
         */
        @Override
        public int nextIndex() {
            return next;
        }

        /**
         * Provides the previous index
         *
         * @return Returns the previous index
         */
        @Override
        public int previousIndex() {
            return next - 1;
        }

        /**
         * Removes the next element, as long the next() method has been called only once, and the element hasn't been removed more than once; throws exception if there is only one or no elements in the array
         */
        public void remove() {
            if (mySize < 0 || !canRemove) {
                throw new IllegalStateException("Nothing to remove");
            } else {
                if(size() == 0){
                    CS2ArrayList.this.remove(0);
                }
                if (next < last) {
                        CS2ArrayList.this.remove(next);
                } else {
                    CS2ArrayList.this.remove(next - 1);
                    next--;
                    last = next;
                }
                canRemove = false;
                canSet = false;
            }
        }

        /**
         * Sets the given value at the previous or next index (works two ways); throws an exception if there is nothing to set
         *
         * @param e Sets the given element e to the next or previous index within the data structure
         */
        @Override
        public void set(E e) {
            if(!canSet){
                throw  new IllegalStateException("Nothing to set");
            }
            if (hasNext()) {
                CS2ArrayList.this.set(next, e);
            } else if (hasPrevious()) {
                CS2ArrayList.this.set(previousIndex(), e);
            }
            canRemove = false;
            canSet = false;
        }

        /**
         * Adds the given value at the previous or next index (works two ways); throws an exception if there is nothing to add
         *
         * @param e Given element e that user wants to be added to the data structure
         */
        @Override
        public void add(E e) {
            canAdd = false;
            canSet = false;
            if (hasNext() && next() != null) {
                CS2ArrayList.this.add(next - 1, e);
            } else {
                CS2ArrayList.this.add(next, e);
            }
        }
    }
}
