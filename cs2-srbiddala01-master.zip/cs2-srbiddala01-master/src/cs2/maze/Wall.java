package cs2.maze;

import info.gridworld.actor.Rock;

public class Wall extends Rock {
    public Wall(){
        this.setColor(null);
    }
}
