package cs2.maze;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;

import java.util.Stack;

public class MazeRunner {
    public static void main(String[] args) {
        Maze maze = new Maze(20,20);
//        ActorWorld world = maze.printWorld(new Bug(),new Bug());
//        world.show();

       // maze.printWorld(new Bug(),new Cheese()).show();

        maze.printWorld(new Mouse(),new Cheese()).show();
    }
}
