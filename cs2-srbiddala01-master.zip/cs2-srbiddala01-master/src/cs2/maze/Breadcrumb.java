package cs2.maze;

import info.gridworld.actor.Actor;

public class Breadcrumb extends Actor {
    public Breadcrumb(){
        this.setColor(null);
    }
}
