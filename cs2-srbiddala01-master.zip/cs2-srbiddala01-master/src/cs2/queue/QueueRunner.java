package cs2.queue;

public class QueueRunner {
    public static void main(String[] args) {
        CS2Queue<String> q = new CS2Queue<String>();
        q.add ("A");
        q.add ("B");
        q.add ("C");
        System.out.println (q.remove());
        q.add ("D");
        System.out.println (q.remove());
        System.out.println (q.remove());
        System.out.println (q.remove());
    }

}
