package cs2.bst;

import com.sun.source.tree.Tree;

import java.util.LinkedList;
import java.util.List;

public class BST <E extends Comparable<E>> {
    //Instance Variables
    private TreeNode root;

    //add
    public boolean add(E val){
        if(root == null){
            root = new TreeNode(val);
            return true;
        } else{
            return add(root, new TreeNode(val));
        }
    }
    //overloaded add
    private boolean add (TreeNode subRoot, TreeNode node) {
        // recursively inserts node into sub-tree at subRoot
        // returns false if not added (because it already contains it)
        if(subRoot.equals(node)){
            return false;
        } else if(node.compareTo(subRoot) < 0){
            if(subRoot.getLeft() == null){
                subRoot.setLeft(node);
                return true;
            } else {
                return add(subRoot.getLeft(), node);
            }
        } else if(node.compareTo(subRoot) > 0){
            if(subRoot.getRight() == null){
                subRoot.setRight(node);
                return true;
            } else {
                return add(subRoot.getRight(), node);
            }
        }
        return true;
    }
    //contains method
    public boolean contains (E value) {
        if (root == null) {
            return false;
        }
        else {
            return contains (root, new TreeNode(value));
        }
    }
    //overloaded contains method
    private boolean contains (TreeNode subRoot, TreeNode node) {
        // recursively check for node in the sub-tree
        if(subRoot.equals(node)){
            return true;
        } else if(node.compareTo(subRoot) < 0){
            if(subRoot.getLeft() == null){
                return false;
            } else {
                return contains(subRoot.getLeft(), node);
            }
        } else if(node.compareTo(subRoot) > 0){
            if(subRoot.getRight() == null){
                return false;
            } else {
                return contains(subRoot.getRight(), node);
            }
        }
        return false;
    }
    //level method
    public int level (E value) {
        if (root == null) {
            return -1;
        }
        else {
            return level (root, new TreeNode(value), 0);
        }
    }
    //overloaded level method
    private int level (TreeNode subRoot, TreeNode node, int level) {
        // recursively get the level of the node
        // if found, return level.  if not found, return -1
        // when recursing, increment level
        if(subRoot.equals(node)){
            return level;
        } else if (subRoot.compareTo(node) > 0){
            if(subRoot.getLeft() == null){
                return -1;
            }
            return level(subRoot.getLeft(), node, level + 1);
        } else if(subRoot.compareTo(node) < 0){
            if(subRoot.getRight() == null){
                return -1;
            }
            return level(subRoot.getRight(), node, level + 1);
        } else{
            return -1;
        }
    }
    //in-order method
    public List<E> inOrderTraversal() {
        List<E> list = new LinkedList<E>();
        inOrderTraversal (root, list);
        return list;
    }
    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void inOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if(subRoot == null){
            return;
        } else {
            inOrderTraversal(subRoot.getLeft(), list);
            list.add(subRoot.getValue());
            inOrderTraversal(subRoot.getRight(), list);
        }
    }
    //reverse-order method
    public List<E> reverseOrderTraversal() {
        List<E> list = new LinkedList<E>();
        reverseOrderTraversal (root, list);
        return list;
    }
    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void reverseOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if(subRoot == null){
            return;
        } else {
            reverseOrderTraversal(subRoot.getRight(), list);
            list.add(subRoot.getValue());
            reverseOrderTraversal(subRoot.getLeft(), list);
        }
    }
    //pre-order method
    public List<E> preOrderTraversal() {
        List<E> list = new LinkedList<E>();
        preOrderTraversal (root, list);
        return list;
    }
    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void preOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if(subRoot == null){
            return;
        } else {
            list.add(subRoot.getValue());
            preOrderTraversal(subRoot.getLeft(), list);
            preOrderTraversal(subRoot.getRight(), list);
        }
    }
    //post-order method
    public List<E> postOrderTraversal() {
        List<E> list = new LinkedList<E>();
        postOrderTraversal (root, list);
        return list;
    }
    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void postOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if(subRoot == null){
            return;
        } else {
            postOrderTraversal(subRoot.getLeft(), list);
            postOrderTraversal(subRoot.getRight(), list);
            list.add(subRoot.getValue());
        }
    }
    //toString method
    public String toString (){
        if(root != null){
            return toString(root, 0);
        }
        return "";
    }
    //overloaded toString
    private String toString(TreeNode subRoot, int level){
        // Build String for right sub-tree (recursively)
        // add "level" dashes then the subRoot's value
        // add String for left sub-tree (recursively)
        // return combined string (put \n between lines)
        String right = "";
        String left = "";
        String middle = "";
        if(subRoot == null){
            return "";
        } else {
            for(int i = 0; i < level; i++){
                middle += "-";
            }
            right = toString(subRoot.getRight(), level + 1) + '\n';
            middle += subRoot.getValue();
            left = toString(subRoot.getLeft(), level + 1);
        }
        return right + middle + left;
    }
    private class TreeNode implements Comparable<TreeNode>{
        //Instance Variable
        private E value;
        private TreeNode left;
        private TreeNode right;
        private TreeNode parent;
        //Constructor
        public TreeNode(E val){
            value = val;
            left = null;
            right = null;
            parent = null;
        }
        //Getters and Setters
        public E getValue(){return value;}
        public void setValue(E val){value = val;}
        public TreeNode getLeft(){return left;}
        public void setLeft(TreeNode lef){left = lef;}
        public TreeNode getRight(){return right;}
        public void setRight(TreeNode righ){right = righ;}
        public TreeNode getParent(){return parent;}
        public void setParent(TreeNode par){parent = par;}
        //equals method
        public boolean equals(TreeNode o){
            return this.getValue().equals(o.getValue());
        }
        //compareTo method
        @Override
        public int compareTo(TreeNode o) {
            return this.getValue().compareTo(o.getValue());
        }
    }
}
