package cs2.stack;

import cs2.linkedList2.CS2LinkedList;
import java.util.LinkedList;

import java.util.Iterator;

public class CS2Stack<E> {
    private CS2LinkedList<E> stack;

    public CS2Stack(){
        stack = new CS2LinkedList<E>();
    }

    public void push(E item){
        stack.add(0, item);
    }
    public E pop(){
        return stack.remove(0);
    }
    public boolean empty(){
        if (stack.size() == 0){
            return true;
        }
        return false;
    }
    public E peek(){
        return stack.get(0);
    }
    public int search(Object o){
        int index = -1;
        for(int i = 0; i < stack.size(); i++){
            if(stack.get(i).equals(o)){
                index = i + 1;
            }
        }
        return index;
    }

    public String toString(){
        return stack.toString();
    }
}
