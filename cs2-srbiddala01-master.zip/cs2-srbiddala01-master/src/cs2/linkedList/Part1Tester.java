package cs2.linkedList;

public class Part1Tester {
    public static void main(String[] args) {

        // test constructor
        System.out.println("Create new empty list: {} and 0:");
        CS2LinkedList<Double> list = new CS2LinkedList<Double>();
        System.out.println(list);
        System.out.println(list.size());

        // test add
        System.out.println("\nAdd items: {[0]:1.0 [1]:18.0 [2]:19.0} and size 3:");
        list.add(1.0);
        list.add(18.0);
        list.add(19.0);
        System.out.println(list);
        System.out.println(list.size());

        // add to beginning with index
        System.out.println("\nadd to beginning using index: {[0]:0.0 [1]:1.0 [2]:18.0 [3]:19.0} and size 4:");
        try {
            list.add(0, 0.0);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(list);
        System.out.println(list.size());

        // test add at index
        System.out.println("\nFill remaining positions 0.0 through 19.0: {[0]:0.0 [1]:1.0 [2]:2.0 [3]:3.0 [4]:4.0 [5]:5.0 [6]:6.0 [7]:7.0 [8]:8.0 [9]:9.0 [10]:10.0 [11]:11.0 [12]:12.0 [13]:13.0 [14]:14.0 [15]:15.0 [16]:16.0 [17]:17.0 [18]:18.0 [19]:19.0}");
        for (int i = 2; i < 18; i++) {
            list.add(i, (double) i);
        }
        System.out.println(list);

        // add to end with index
        System.out.println("\nadd to end using index:");
        try {
            list.add(20, 20.0);
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println(list);

        // test get
        System.out.println("Testing gets - print values 0.0 through 20.0:");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
        }
        System.out.println();

        // force exception
        System.out.println("\nAttempt to get invalid index (21) - catch error:");
        try {
            list.get(21);
        } catch (Exception e) {
            System.out.println(e);
        }

        // test set (will print 0 through 20, and set to 20 through 0)
        System.out.println("\nTest set: print retrieved values (0.0 through 20.0) and reset to 20.0 through 0.0");
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.set(i, 20.0 - i) + " ");
        }
        System.out.println();
        System.out.println(list);

        // force exception
        System.out.println("\nAttempt to set invalid index (21) - catch error:");
        try {
            list.set(21, 3.0);
        } catch (Exception e) {
            System.out.println(e);
        }

        // test removals
        System.out.println("\nTest removals");
        System.out.println("\nRemove first value (20.0)");
        System.out.println(list.remove(0));
        System.out.println("\nRemove last value (0.0)");
        System.out.println(list.remove(list.size()-1));

        System.out.println("\nRemove remaining values in random order");
        int size = list.size();
        for (int i = 0; i < size; i++) {
            int index = (int)(Math.random()*list.size());
            System.out.print("Removing from index " + index + " ("+ list.get(index) + "): " + list.remove(index) + "\n");
        }
        System.out.println("\nList should now be empty: " + list);

        // force exception
        System.out.println("\nAttempt to remove from an empty list - catch error");
        try {
            list.remove(0);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
