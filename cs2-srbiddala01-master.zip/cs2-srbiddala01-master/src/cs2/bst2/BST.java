package cs2.bst2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;

public class BST<E extends Comparable<E>> implements Iterable<E> {
    //Instance Variables
    private TreeNode root;
    private int size = 0;

    //size method{
    public int size() {
        return size;
    }

    //add
    public boolean add(E val) {
        if (root == null) {
            root = new TreeNode(val);
            size += 1;
            return true;
        } else {
            boolean ifAdded = add(root, new TreeNode(val));
            if (ifAdded) {
                size += 1;
            }
            return ifAdded;
        }
    }

    //overloaded add
    private boolean add(TreeNode subRoot, TreeNode node) {
        // recursively inserts node into sub-tree at subRoot
        // returns false if not added (because it already contains it)
        if (subRoot.equals(node)) {
            return false;
        } else if (node.compareTo(subRoot) < 0) {
            if (subRoot.getLeft() == null) {
                subRoot.setLeft(node);
                node.setParent(subRoot);
                return true;
            } else {
                return add(subRoot.getLeft(), node);
            }
        } else if (node.compareTo(subRoot) > 0) {
            if (subRoot.getRight() == null) {
                subRoot.setRight(node);
                node.setParent(subRoot);
                return true;
            } else {
                return add(subRoot.getRight(), node);
            }
        }
        return true;
    }

    //contains method (IMPORTANT)
    public boolean contains(E value) {
        if (root == null) {
            return false;
        } else {
            return contains(root, new TreeNode(value));
        }
    }

    //overloaded contains method
    private boolean contains(TreeNode subRoot, TreeNode node) {
        // recursively check for node in the sub-tree
        if (subRoot.equals(node)) {
            return true;
        } else if (node.compareTo(subRoot) < 0) {
            if (subRoot.getLeft() == null) {
                return false;
            } else {
                return contains(subRoot.getLeft(), node);
            }
        } else if (node.compareTo(subRoot) > 0) {
            if (subRoot.getRight() == null) {
                return false;
            } else {
                return contains(subRoot.getRight(), node);
            }
        }
        return false;
    }

    //level method
    public int level(E value) {
        if (root == null) {
            return -1;
        } else {
            return level(root, new TreeNode(value), 0);
        }
    }

    //overloaded level method
    private int level(TreeNode subRoot, TreeNode node, int level) {
        // recursively get the level of the node
        // if found, return level.  if not found, return -1
        // when recursing, increment level
        if (subRoot.equals(node)) {
            return level;
        } else if (subRoot.compareTo(node) > 0) {
            if (subRoot.getLeft() == null) {
                return -1;
            }
            return level(subRoot.getLeft(), node, level + 1);
        } else if (subRoot.compareTo(node) < 0) {
            if (subRoot.getRight() == null) {
                return -1;
            }
            return level(subRoot.getRight(), node, level + 1);
        } else {
            return -1;
        }
    }

    //in-order method
    public List<E> inOrderTraversal() {
        List<E> list = new LinkedList<E>();
        inOrderTraversal(root, list);
        return list;
    }

    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void inOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if (subRoot == null) {
            return;
        } else {
            inOrderTraversal(subRoot.getLeft(), list);
            list.add(subRoot.getValue());
            inOrderTraversal(subRoot.getRight(), list);
        }
    }

    //reverse-order method
    public List<E> reverseOrderTraversal() {
        List<E> list = new LinkedList<E>();
        reverseOrderTraversal(root, list);
        return list;
    }

    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void reverseOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if (subRoot == null) {
            return;
        } else {
            reverseOrderTraversal(subRoot.getRight(), list);
            list.add(subRoot.getValue());
            reverseOrderTraversal(subRoot.getLeft(), list);
        }
    }

    //pre-order method
    public List<E> preOrderTraversal() {
        List<E> list = new LinkedList<E>();
        preOrderTraversal(root, list);
        return list;
    }

    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void preOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if (subRoot == null) {
            return;
        } else {
            list.add(subRoot.getValue());
            preOrderTraversal(subRoot.getLeft(), list);
            preOrderTraversal(subRoot.getRight(), list);
        }
    }

    //post-order method
    public List<E> postOrderTraversal() {
        List<E> list = new LinkedList<E>();
        postOrderTraversal(root, list);
        return list;
    }

    /**
     * postcondition: list is mutated - values are added to the end
     */
    private void postOrderTraversal(TreeNode subRoot, List<E> list) {
        // build list recursively
        if (subRoot == null) {
            return;
        } else {
            postOrderTraversal(subRoot.getLeft(), list);
            postOrderTraversal(subRoot.getRight(), list);
            list.add(subRoot.getValue());
        }
    }

    //clear method
    public void clear() {
        size = 0;
        root = null;
    }

    //remove method
    public boolean remove(E val) {
        TreeNode values = new TreeNode(val);
        boolean hasRemoved = remove(root, values);
        if (hasRemoved) {
            size -= 1;
        }
        return hasRemoved;
    }

    //overloaded remove method
    private boolean remove(TreeNode subRoot, TreeNode node) {
        TreeNode temp = subRoot;
        if (temp == null) {
            return false;
        }
        while (!temp.equals(node)) {
            if (temp.compareTo(node) > 0) {
                if (temp.getLeft() != null) {
                    temp = temp.getLeft();
                } else {
                    return false;
                }
            } else {
                if (temp.getRight() != null) {
                    temp = temp.getRight();
                } else {
                    return false;
                }
            }
        }
        //leaf (special case 1-node only)
        // To remove it, just set root to null and let the node get garbage-collected
        if (size == 1) {
            root = null;
            return true;
        }
        //leaf
        // Find the node to remove
        // Set that node's parent's nextLeft or nextRight
        // (how do you know which?) to null thus disconnecting the node
        // The removed node will be garbage-collected
        else if (temp.getLeft() == null && temp.getRight() == null) {
            if (temp.getParent().getLeft().equals(node)) {
                temp.getParent().setLeft(null);
                return true;
            } else {
                temp.getParent().setRight(null);
                return true;
            }
        } else if (temp.getLeft() == null || temp.getRight() == null) {
            //one-child special case (remove root)
            // If the node to be removed only has one child AND its parent is the root instance variable, just reset root to point to the single child (and reset the child's parent to null)
              if (temp.equals(root)) {
                if (temp.getLeft() == null) {
                    root = temp.getRight();
                    temp = null;
                    System.out.println(root.getValue());
                    return true;
                } else {
                    root = temp.getLeft();
                    temp = null;
                    System.out.println(root.getValue());
                    return true;
                }
            }
            // set parent did 10 down to 9 but not 9 up to 10
            else {
                //one-child
                // Find the node to remove
                // Set its parent's Left or Right child (whichever it is) to reference its single child (in this case link the 3's left child to the 2 and skip over the 1)
                // The removed node will be garbage collected
                if (node.equals(temp.getParent().getLeft()) && temp.getLeft() != null && temp.getRight() == null) {
                    temp.getParent().setLeft(temp.getLeft());
                    temp.getLeft().setParent(temp.getParent());
                } else if (node.equals(temp.getParent().getLeft()) && temp.getLeft() == null && temp.getRight() != null) {
                    temp.getParent().setLeft(temp.getRight());
                    temp.getRight().setParent(temp.getParent());
                } else if (node.equals(temp.getParent().getRight()) && temp.getLeft() != null && temp.getRight() == null) {
                    temp.getParent().setRight(temp.getLeft());
                    temp.getLeft().setParent(temp.getParent());
                } else {
                    temp.getParent().setRight(temp.getRight());
                    temp.getRight().setParent(temp.getParent());
                }
                return true;
            }
        }
        //two-children
        // Find the node to remove
        // Then, find the largest  value to the left of that node
        // Recursively delete that largest value from the left subtree
        // Replace the node's value with that largest value to the left
        else {
            TreeNode temp2 = temp;
            temp2 = temp2.getLeft();
            while (temp2.getRight() != null) {
                temp2 = temp2.getRight();
            }
            remove(temp.getLeft(), temp2);
            temp.setValue(temp2.getValue());
        }
        return true;
    }

    //toString method
    public String toString() {
        if (root != null) {
            return toString(root, 0);
        }
        return "";
    }

    //overloaded toString
    private String toString(TreeNode subRoot, int level) {
        // Build String for right sub-tree (recursively)
        // add "level" dashes then the subRoot's value
        // add String for left sub-tree (recursively)
        // return combined string (put \n between lines)
        String right = "";
        String left = "";
        String middle = "";
        if (subRoot == null) {
            return "";
        } else {
            for (int i = 0; i < level; i++) {
                middle += "-";
            }
            right = toString(subRoot.getRight(), level + 1) + '\n';
            middle += subRoot.getValue();
            left = toString(subRoot.getLeft(), level + 1);
        }
        return right + middle + left;
    }

    @Override
    public Iterator<E> iterator() {
        return new CS2TreeIterator();
    }

    private class CS2TreeIterator<E> implements Iterator<E> {
        private int next = 0;
        private E nextVal;
        private ArrayList<E> tempList = new ArrayList<>();

        private CS2TreeIterator(){
            Iterator<E> it = (Iterator<E>) inOrderTraversal().iterator();
            for(int i = 0; i < inOrderTraversal().size(); i++){
                tempList.add(it.next());
            }
        }

        @Override
        public boolean hasNext() {
            if (tempList.size() > 0 && next < tempList.size()) {
                return true;
            } else {
                return false;
            }
        }

        @Override
        public E next() {
            E ret = null;
            if (hasNext()) {
                ret = tempList.get(next++);
            }
            nextVal = ret;
            return ret;
        }
    }

    private class TreeNode implements Comparable<TreeNode> {
        //Instance Variable
        private E value;
        private TreeNode left;
        private TreeNode right;
        private TreeNode parent;

        //Constructor
        public TreeNode(E val) {
            value = val;
            left = null;
            right = null;
            parent = null;
        }

        //Getters and Setters
        public E getValue() {
            return value;
        }

        public void setValue(E val) {
            value = val;
        }

        public TreeNode getLeft() {
            return left;
        }

        public void setLeft(TreeNode lef) {
            left = lef;
        }

        public TreeNode getRight() {
            return right;
        }

        public void setRight(TreeNode righ) {
            right = righ;
        }

        public TreeNode getParent() {
            return parent;
        }

        public void setParent(TreeNode par) {
            parent = par;
        }

        //equals method
        public boolean equals(TreeNode o) {
            return this.getValue().equals(o.getValue());
        }

        //compareTo method
        @Override
        public int compareTo(TreeNode o) {
            return this.getValue().compareTo(o.getValue());
        }
    }


}
