package cs2.morse;

import cs2.hash.CS2HashMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.Scanner;

public class MorseRunner {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner reader = new Scanner(new File("MorseCode.txt"));
        //String[] arr = new String[100];
        CS2HashMap<String,String> hashMap = new CS2HashMap<>(10);
        while(reader.hasNext()){
            String input = reader.nextLine();
            //int key = (int) input.charAt(0);
            //arr[key] = input.substring(2);
            String substring = input.substring(0,1);
            String value = hashMap.get(substring);
            value = input.substring(2);
        }
        reader.close();
//        for(int i = 0; i < arr.length; i++){
//            System.out.println("Char: " + i + " Morse Code: " + arr[i]);
//        }
        for(int i = 0; i < hashMap.size(); i++){
            System.out.println("Char: " + i + " Morse Code: " + hashMap.get("" + i + ""));
        }
        reader = new Scanner(System.in);
        System.out.print("Enter a character: ");
        String resp = reader.next();
        resp = resp.toUpperCase(Locale.ROOT);
//        for(int i = 0; i < resp.length(); i++){
//            System.out.print(arr[resp.charAt(i)] + " ");
//        }
        for(int i = 1; i < resp.length(); i++){
            System.out.print(hashMap.get(resp.substring(i - 1, i)) + " ");
        }
    }
}
