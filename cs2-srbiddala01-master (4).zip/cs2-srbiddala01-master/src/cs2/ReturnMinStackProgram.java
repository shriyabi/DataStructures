package cs2;

import cs2.queue.CS2Queue;

import java.util.Stack;

public class ReturnMinStackProgram {
    public static int getMin(Stack<Integer> s) {
        Stack<Integer> stack = new Stack<>();
        stack.push(s.pop());
        for(Integer val: s){
            if(stack.peek() > val){
                stack.push(val);
            }
        }
        return stack.peek();
    }

    public static void main(String[] args) {
        Stack<Integer> stk = new Stack<>();
        stk.push(29);
        stk.push(81);
        stk.push(76);
        stk.push(35);
        stk.push(16);
        System.out.println(getMin(stk));
    }
}
