package cs2.arrayList;

import cs2.CS2List;

public class CS2ArrayList<E> implements CS2List<E> {
    public void setMyList(E[] myList) {
        this.myList = myList;
    }

    //Instance variables
    private E myList[];
    private int mySize;

    //Constructor
    public CS2ArrayList() {
        myList = (E[]) (new Object[20]);
        mySize = 0;
    }

    //Public Methods
    @Override
    public int size() {
        return mySize;
    }

    @Override
    public boolean add(E obj) {
        mySize++;
        if (mySize >= myList.length) {
            this.expand();
        }
        myList[mySize - 1] = obj;
        return true;
    }

    @Override
    public void add(int index, E obj) {
        if (index < 0) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        mySize++;
        if (mySize >= myList.length || index > myList.length) {
            this.expand();
        }
        for (int i = myList.length - 1; i > index; i--) {
            myList[i] = myList[i - 1];
        }
        myList[index] = obj;
    }

    @Override
    public E get(int index) {
        if (index < 0 || index >= mySize) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        return myList[index];
    }

    @Override
    public E set(int index, E obj) {
        if (index < 0 || index > myList.length) {
            throw new RuntimeException("Index " + index + " is not in range");
        }
        E temp = myList[index];
        myList[index] = obj;
        return temp;
    }

    @Override
    public E remove(int index) {
        if (index < 0 || index >= mySize) {
            throw new RuntimeException("Index " + index + " is not in length");
        }
        E temp = myList[index];
        mySize--;
        for (int i = index; i < myList.length - 1; i++) {
            myList[i] = myList[i + 1];
        }
        return temp;
    }

    private void expand() {
        if (mySize >= myList.length) {
            E[] biggerArray = (E[]) (new Object[(int) (myList.length * 1.5)]);
            for (int i = 0; i < myList.length; i++) {
                biggerArray[i] = myList[i];
            }
            setMyList(biggerArray);
        }
    }

    public String toString() {
        String info = "";
        if (mySize == 0) {
            info = "";
        } else {
            for (int i = 0; i < mySize; i++) {
                info = info + " [" + i + "]: " + myList[i];
            }
        }
        return "{" + info + "}";
    }
}
