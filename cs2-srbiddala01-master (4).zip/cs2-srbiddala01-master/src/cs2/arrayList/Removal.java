package cs2.arrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class Removal {
    public static void main(String[] args) {
        ArrayList<Integer> arr = new ArrayList<>();
        for(int i = 0; i < 20; i++){
            int randomNumber = (int)(Math.random() * 21 - 10);
            arr.add(randomNumber);
        }
      //  System.out.println(arr);
        Iterator<Integer> it = arr.iterator();
        while(it.hasNext()){
            Integer i = it.next();
            System.out.print(i + " ");
        }
        System.out.println();
      /*  for(int j = 0; j < arr.size(); j++){
            if(arr.get(j) < 0){
                arr.remove(j);
                j--;
            }
        } */
        it = arr.iterator();
        while(it.hasNext()){
            if(it.next() < 0){
                it.remove();
            }
        }
        System.out.println(arr);
    }
}
