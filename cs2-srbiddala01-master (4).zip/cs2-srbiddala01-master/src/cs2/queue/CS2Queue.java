package cs2.queue;

import cs2.linkedList.CS2LinkedList;

import java.util.LinkedList;

public class CS2Queue<E>{
   // private LinkedList<E> list;
    private CS2LinkedList<E> list;
    public CS2Queue(){
        list = new CS2LinkedList<>();
    }
    public void add(E item){
        list.add(list.size(), item);
    }
    public E remove(){
        return list.remove(0);
    }
    public E peek(){
        return list.get(0);
    }
    public String toString(){
        return list.toString();
    }

}
