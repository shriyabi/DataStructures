package cs2.linkedList2;

import cs2.CS2List;
import cs2.arrayList2.CS2ArrayList;

import java.util.Iterator;

public class CS2LinkedList<E> implements CS2List<E>, Iterable<E> {
    //INSTANCE VARIABLES
    private ListNode head;
    private int mySize;
    private ListNode tail;

    //CONSTRUCTOR
    public CS2LinkedList() {
        head = null;
        mySize = 0;
        tail = null;
    }

    @Override
    public int size() {
        return mySize;
    }

    @Override
    public boolean add(E obj) {
        ListNode temp = new ListNode(obj);
        if (size() == 0) {
            head = temp;
            tail = temp;
        } else {
            tail.setNext(temp);
            temp.setPrev(tail);
            tail = temp;
        }
        mySize++;
        return true;
    }

    @Override
    public void add(int index, E obj) {
        if (index >= size() || index < 0) {
            throw new IndexOutOfBoundsException("index invalid");
        }
        ListNode indexNode = head;
        ListNode insertNode = new ListNode(obj);
        if(size() == 0){
            head = insertNode;
            tail = insertNode;
        } else if (index == 0) {
            insertNode.setNext(head);
            head = insertNode;
        } else if (index == size()) {
            ListNode temp = tail;
            tail.setNext(insertNode);
            tail = insertNode;
            tail.setPrev(temp);
        } else {
            for (int i = 0; i < index - 1; i++) {
                indexNode = indexNode.getNext();
            }
            ListNode nextNode = indexNode.getNext();
            indexNode.setNext(insertNode);
            insertNode.setPrev(indexNode);
            insertNode.setNext(nextNode);
            nextNode.setPrev(insertNode);
        }
        mySize++;
    }

    @Override
    public E get(int index) {
        if(index >= size()){
            throw new IndexOutOfBoundsException("index invalid");
        }
        ListNode indexNode = head;
        for(int i = 0; i < index; i++){
            indexNode = indexNode.getNext();
        }
        return indexNode.getValue();
    }

    @Override
    public E set(int index, E obj) {
        if (index >= size()) {
            throw new IndexOutOfBoundsException("index invalid");
        }
        ListNode indexNode = head;
        for (int i = 0; i < index; i++) {
            indexNode = indexNode.getNext();
        }
        E originalValue = indexNode.getValue();
        indexNode.setValue(obj);
        return originalValue;
    }

    @Override
    public E remove(int index) {
        if (index >= size() || index < 0 ) {
            throw new IndexOutOfBoundsException("index invalid");
        }
        ListNode indexNode = head;
        ListNode prevNode = head;
        E temp = null;
        if(size() == 1){
            temp = head.getValue();
            head = null;
            tail = null;
        } else if (index == 0) {
            temp = head.getValue();
            head = head.getNext();
            head.setPrev(null);
        } else if (index == size() - 1) {
            temp = tail.getValue();
            tail = tail.getPrev();
            tail.setNext(null);
        } else {
            for(int i = 0; i < index; i++){
                prevNode = indexNode;
                indexNode = indexNode.getNext();
                temp = indexNode.getValue();
            }
            prevNode.setNext(indexNode.getNext());
            indexNode.getNext().setPrev((prevNode));
        }
        mySize--;
        return temp;
    }


    public String toString() {
        String ret = "";
        if (head == null) {
            ret = "Empty list";
        } else {
            ListNode nextElement = head;
            int index = 0;
            while (nextElement != null) {
                ret += " [" + index + "] " + nextElement.getValue();
                nextElement = nextElement.getNext();
                index++;
            }
        }
        return ret;
    }
    public Iterator<E> iterator(){return new CS2Iterator();}
    private class ListNode {
        //Instance Variables
        private E value;
        private ListNode next;
        private ListNode prev;

        //Constructor
        public ListNode(E givenValue) {
            value = givenValue;
            next = null;
            prev = null;
        }

        //Getters and Setters
        public E getValue() {
            return value;
        }

        public void setValue(E value) {
            this.value = value;
        }

        public ListNode getNext() {
            return next;
        }

        public void setNext(ListNode next) {
            this.next = next;
        }

        public ListNode getPrev() {
            return prev;
        }

        public void setPrev(ListNode prev) {
            this.prev = prev;
        }



    }


    private class CS2Iterator implements Iterator<E>{
        public ListNode next;
        public boolean canRemove;

        public CS2Iterator(){
            next = head;
            canRemove = false;
        }

        @Override
        public boolean hasNext() {
            if (next != null){
                return true;
            } else{
                return false;
            }
        }

        @Override
        public E next() {
            canRemove = true;
            E ret = null;
            ret = next.getValue();
            next = next.getNext();
            return ret;

        }

        public void remove() {
            if (!canRemove) {
                throw new IllegalStateException("nothing to remove");
            } else if (!hasNext()) {
                CS2LinkedList.this.remove(mySize - 1);
            } else if (head == next.getPrev()) {
                CS2LinkedList.this.remove(0);
                next.setPrev(null);
            } else {
                ListNode prev = next.getPrev();
                ListNode prevprev = prev.getPrev();
                prevprev.setNext(next);
                next.setPrev(prevprev);
            }
            mySize--;
            canRemove = false;
        }
    }
}



