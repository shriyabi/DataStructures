package cs2.zip;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ZipRunner {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner reader = new Scanner(new File("zipcodes.txt"));
       // Map<Integer, String> map = new TreeMap<Integer, String>();
       // Map<Integer, String> map = new HashMap<Integer, String>();
        String[] arr = new String[100000];

        while(reader.hasNext()){
            String input = reader.nextLine();
            int zipCode = Integer.parseInt(input.substring(0,5).strip());
            String city  = input.substring(6);
            arr[zipCode] = city;
            //map.put(zipCode, city);
        }
        reader.close();

        for(int i = 0; i < arr.length; i++){
            System.out.println("Zipcode: " + i + " City: " + arr[i]);
        }

//        Set<Integer> key = map.keySet();
//        for(Integer val: key){
//            System.out.println("Zipcode: " + val + " City: " + map.get(val));
//        }

        reader = new Scanner(System.in);
        System.out.print("Enter a zip: ");
        int zip = reader.nextInt();
        // System.out.println(map.get(zip));
        System.out.println(arr[zip]);
    }
}
