package cs2.hash;

import java.util.Scanner;

public class ShowHash {
    public static void main(String[] args){
        Scanner reader = new Scanner(System.in);
        System.out.println("Enter a String");
        String str = reader.nextLine();
        while(!str.equals("q")){
            System.out.println("Hash Code for " + str + " is " + Math.abs(str.hashCode() % 13));
            str = reader.nextLine();
        }
    }

    //Collision Handling - "chaining"
        //Call each item in the array a "bucket"
        //Hash table is array of buckets where each bucket can hold all colliding key/value pairs
        //Use a BST (or LinkedList) to hold all values in one bucket
        //Array of LinkedLists which hold key/value pairs: linked list hold all values with keys that map to the same index in separate nodes
        //Bigger hashtable = less collisions
    //Collision Handling - "linear probing"
        //If a Collision is detected, move on to another index until a vacant spot is found

}
