package cs2.hash;

import java.awt.*;
import java.util.*;

public class CS2HashMap<K extends Comparable<K>, V> {
    private ArrayList<LinkedList<KeyValue>> hashTable;

    public CS2HashMap(int numOfBuckets){
        hashTable = new ArrayList<>();
        for(int i = 0; i < numOfBuckets; i++){
            LinkedList<KeyValue> temp = new LinkedList<>();
            hashTable.add(temp);
        }
    }

    private class KeyValue {
        public K key;
        public V value;

        public KeyValue (K key, V value) {
            this.key = key;
            this.value = value;
        }

        public String toString() {
            return "["+key+", "+value+"]";
        }
    }

    //size() - returns the size of the HashMap
    public int size(){
        int num = 0;
        for(LinkedList<KeyValue> bucket: hashTable){
            num += bucket.size();
        }
        return num;
    }
    //put(K key, V value)
    //Inserts the key/value pair into the HashMap.  If there is already an entry with the key supplied, the HashMap is updated to the new key/value pair and the old value is returned.  Otherwise null is returned
        //locate the index of the bucket
        //Use an enhanced-for to iterate through the bucket's CS2LinkedList.  If a KeyValue pair is found with a matching key, update its value and return the old value.   If not found, add a new KeyValue to the end of the CS2LinkedList
    public V put(K key, V value){
        int index = Math.abs(key.hashCode() % hashTable.size());
        for(KeyValue keyVals: hashTable.get(index)){
            if(keyVals.key.equals(key)){
                V val = keyVals.value;
                keyVals.value = value;
                return val;
            }
        }
        hashTable.get(index).add(new KeyValue(key, value));
        return null;
    }
    //get(K key) - for a given key, return the corresponding value.
    //Use an enhanced-for to iterate through the bucket's CS2LinkedList.  If a KeyValue pair is found with a matching key, return that KeyValue pair's value.  Otherwise return null.
    public V get(K key){
        int index = Math.abs(key.hashCode() % hashTable.size());
        for(KeyValue keyVals: hashTable.get(index)){
            if(keyVals.key.equals(key)){
                return keyVals.value;
            }
        }
        return null;
    }
    public String toString(){
        String str = "";
        for(int i = 0; i < hashTable.size(); i++){
            str += hashTable.get(i) + "\n";
        }
        return str;
    }

    public void clear(){
        for(LinkedList<KeyValue> bucket: hashTable){
            Iterator<KeyValue> it = bucket.iterator();
            while(it.hasNext()){
                it.next();
                it.remove();
            }
        }
    }

    public boolean containsKey(K key){
        int index = Math.abs(key.hashCode() % hashTable.size());
        for(KeyValue keyVals: hashTable.get(index)){
            if(keyVals.key.equals(key)){
                return true;
            }
        }
        return false;
    }

    public boolean containsValue(V value){
        for(LinkedList<KeyValue> bucket: hashTable){
            for(KeyValue pair: bucket){
                if(pair.value.equals(value)){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isEmpty() {
        for(LinkedList<KeyValue> bucket: hashTable){
            if(bucket.size() == 0){
                return true;
            }
        }
        return false;
    }

    public Set<K> keySet(){
         Set<K> key = new TreeSet<>();
         for(LinkedList<KeyValue> bucket: hashTable){
             for(KeyValue pair: bucket){
                 key.add(pair.key);
             }
         }
         return key;
    }

    public V remove(K key){
        V temp = null;
        for(LinkedList<KeyValue> bucket: hashTable){
            for(KeyValue pair: bucket){
                if(pair.key.equals(key)){
                    temp = pair.value;
                    bucket.remove(pair);
                }
            }
        }
        return temp;
    }

    public Collection<V> values(){
        Collection<V> collection = new HashSet<>();
        for(LinkedList<KeyValue> bucket: hashTable){
            for(KeyValue key: bucket){
                collection.add(key.value);
            }
        }
        return collection;
    }
}



