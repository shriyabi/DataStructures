//package cs2;
//
//import cs2.bst.BST;
//
//import javax.swing.tree.TreeNode;
//import java.util.LinkedList;
//import java.util.List;
//
//public class IsBinary {
//    public boolean isBinary(BST<Integer> bst){
//        boolean ret = false;
//        List<Integer> lst = bst.inOrderTraversal();
//        int counter = 0;
//        for(int i = 1; i < lst.size(); i++){
//            int temp = lst.get(i-1);
//            if(temp < lst.get(i)){
//                counter++;
//            }
//        }
//        if(counter == lst.size()){
//            ret = true;
//        }
//        return ret;
//    }
//    public List<Integer> inOrderTraversal(){
//        List<Integer> list = new LinkedList<Integer>();
//        inOrderTraversal(TreeNode root, list);
//        return list;
//    }
//    private void inOrderTraversal(TreeNode subRoot, List<Integer> list){
//        if(subRoot == null){
//            return;
//        } else {
//            inOrderTraversal(subRoot.getLeft(), list);
//            list.add(subRoot.getValue());;
//            inOrderTraversal(subRoot.getRight(), list);
//        }
//    }
//}
//
//
