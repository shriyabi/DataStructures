package cs2.postfix;

import java.util.Scanner;
import java.util.Stack;

public class Runner {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Enter postfix expression ending with a '=': ");
        Stack<Double> stack = new Stack<Double>();
        while (true) {
            try {
               // for(int i = 0; i < resp.length(); i++) {
                    double val = reader.nextDouble();
                    stack.push(val);
                //}
            } catch (Exception e){
                if(stack.size() > 2){
                    throw new RuntimeException("excess operands");
                }
                String operator = reader.next();
                double val1;
                double val2;
                if (operator.equals("=")){
                    break;
                }
                try {
                    val1 = stack.pop();
                    val2 = stack.pop();
                } catch (Exception b) {
                    throw new RuntimeException("not enough operands");
                }
                if(operator.equals("+")){
                    stack.push(val1 + val2);
                } else if(operator.equals("-")){
                    stack.push(val2 - val1);
                } else if(operator.equals("*")){
                    stack.push(val1 * val2);
                } else if (operator.equals("/")){
                    stack.push(val2 / val1);
                } else{
                    throw new RuntimeException("error with operator");
                }
            }
        }
        System.out.println(stack.pop());
    }
}
