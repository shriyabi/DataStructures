package cs2.heap;

public class PQRunner {

    public static void main(String[] args) {

        System.out.println("\nCreate with default sorting (ascending by condition)\n");

        CS2Heap<Patient> heap = new CS2Heap<Patient>();

        heap.add(new Patient("Fleming, Julius", 3));
        heap.add(new Patient("Adkins, Roberta", 3));
        heap.add(new Patient("Jefferson, Bernice", 4));
        heap.add(new Patient("Malone, Gwen", 2));
        heap.add(new Patient("Bowers, Dustin", 2));
        heap.add(new Patient("Powell, Daisy", 4));
        heap.add(new Patient("Briggs, Ramona", 3));
        heap.add(new Patient("Dennis, Kerry", 3));
        heap.add(new Patient("Johnson, Colin", 1));
        heap.add(new Patient("Williams, Danielle", 2));

        while (!heap.isEmpty()) {
            System.out.println(heap.remove() + " ");
        }

        // repeat with different Patient settings
        System.out.println("\nRepeat - sorting by name in descending order\n");
        heap = new CS2Heap<Patient>();
        Patient.sortBy(Patient.BY_NAME);
        Patient.setDirection(Patient.DESC);

        heap.add(new Patient("Fleming, Julius", 3));
        heap.add(new Patient("Adkins, Roberta", 3));
        heap.add(new Patient("Jefferson, Bernice", 4));
        heap.add(new Patient("Malone, Gwen", 2));
        heap.add(new Patient("Bowers, Dustin", 2));
        heap.add(new Patient("Powell, Daisy", 4));
        heap.add(new Patient("Briggs, Ramona", 3));
        heap.add(new Patient("Dennis, Kerry", 3));
        heap.add(new Patient("Johnson, Colin", 1));
        heap.add(new Patient("Williams, Danielle", 2));

        while (!heap.isEmpty()) {
            System.out.println(heap.remove() + " ");
        }
    }
}

