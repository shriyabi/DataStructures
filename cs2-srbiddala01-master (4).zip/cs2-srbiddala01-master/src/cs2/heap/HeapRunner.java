package cs2.heap;

public class HeapRunner {
    public static void main (String argv[]) {
        CS2Heap<Integer> h = new CS2Heap<Integer>();

        System.out.println("Testing toString()");
        h.add (12);
        h.add (20);
        h.add (25);
        h.add (50);
        h.add (75);
        h.add (90);
        System.out.println ("New Heap created:");
        System.out.println ("Size: " + h.size());
        System.out.println ("IsEmpty: " + h.isEmpty());
        System.out.println ("Contents:");
        System.out.println (h);
        h.clear();
        System.out.println("\n");

        System.out.println("Testing add()");
        h.add (90);
        h.add (75);
        h.add (50);
        h.add (25);
        h.add (20);
        h.add (12);
        System.out.println ("New Heap created:");
        System.out.println ("Size: " + h.size());
        System.out.println ("IsEmpty: " + h.isEmpty());
        System.out.println ("Contents:");
        System.out.println (h);
        System.out.println("\n");

        System.out.println("Testing remove()");
        System.out.println ("Removed Values:");
        while (!h.isEmpty()) {
            System.out.print(h.remove() + " ");
        }
        System.out.println("\n");

        System.out.println("Testing clear()");
        h.clear ();
        System.out.println ("Heap cleared:");
        System.out.println ("Size: " + h.size());
        System.out.println ("IsEmpty: " + h.isEmpty());
        System.out.println ("Contents:");
        System.out.println (h);

    }
}
