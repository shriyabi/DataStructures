package cs2.heap;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class HeapSorter {
    /**
     * this static method accepts a List of any Comparable type and
     * replaces its values with the
     * same values but in sorted order.
     *
     * @param list The list to be sorted
     * @param <E> Any Comparable type
     */
    public static<E extends Comparable<E>> void sort (List<E> list) {
        CS2Heap<E> tempVals = new CS2Heap<>();
        for(E vals: list){
            tempVals.add(vals);
        }
        ListIterator<E> it = list.listIterator();
        while(it.hasNext()){
           it.next();
           it.set(tempVals.remove());
        }
    }

    public static void main (String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        for (int i=0; i<100; i++) {
            list.add((int)(Math.random()*50));
        }
        HeapSorter.sort(list);

        System.out.println (list);
    }
}

