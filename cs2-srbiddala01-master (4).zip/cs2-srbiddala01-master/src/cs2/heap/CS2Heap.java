package cs2.heap;

import cs2.bst2.BST;

import java.util.ArrayList;

public class CS2Heap<E extends Comparable<E>> {
    private ArrayList<E> heapVals = new ArrayList<>();

    //ADD - adds to the end of the list
//    public void add(E value) {
//        heapVals.add(value);
//    }
    public void add(E value) {
        // properly add value into Heap so that Heap properties are maintained
        // - add to end
        // - Re-heap "up":
        // - swap with parent repeatedly until at the root or parent is smaller than the added value.
        heapVals.add(value);
        int index = size() - 1;
        int parent = parent(index);
        while (value.compareTo(heapVals.get(parent)) < 0) {
            E temp = heapVals.get(parent);
            heapVals.set(index, temp);
            heapVals.set(parent, value);
            index = parent;
            parent = parent(parent);
        }
    }

        //remove()
    public E remove(){
        // removes root and restores the heap:
        //   - save root value for later return
        //   - copy last value to root
        //   - remove last value from the ArrayList
        //   - re-heap "down":
        // two cases: leftChild(i) > size() -1 || parent val is less than both of the child || parent vale is less than only child
        //      - repeatedly swap a value with "smallest" child (stop when at lowest level or both children are larger). Use a loop or recursion as you see fit
        //   - return the saved original root value
        E rootVal = heapVals.get(0);
        if(heapVals.size() == 0){
            throw new RuntimeException("nothing to remove");
        }
        if (heapVals.size() == 1){
            heapVals.remove(0);
            return rootVal;
        }
        heapVals.set(0, heapVals.get(size() - 1));
        heapVals.remove(size() - 1);
        int i = 0;
        E root = heapVals.get(0);
        while((leftChild(i) <= size() - 1 && rightChild(i) <= size() - 1) && ((root.compareTo(heapVals.get(leftChild(i))) > 0) || (root.compareTo(heapVals.get(rightChild(i))) > 0))){
            if(heapVals.get(leftChild(i)).compareTo(heapVals.get(rightChild(i))) < 0){
                heapVals.set(i, heapVals.get(leftChild(i)));
                heapVals.set(leftChild(i), root);
                i = leftChild(i);
            } else {
                heapVals.set(i, heapVals.get(rightChild(i)));
                heapVals.set(rightChild(i), root);
                i = rightChild(i);
            }
        }
        return rootVal;
    }

    //leftChild() - returns the index of the left child of index i
    private int leftChild(int i) {
        return (i * 2) + 1;
    }

    //rightChild() - returns the index of the right child of index i
    private int rightChild(int i) {
        return leftChild(i) + 1;
    }

    //level() - returns the level for a given index i
    private int level(int i) {
        int ret = 0;
        try {
            ret = (int) Math.log(i + 1) / (int) Math.log(2);
        } catch (Exception e) {
            ret = 0;
        }
        return ret;
        // return (int) Math.log(i + 1) / (int) Math.log(2);
    }

    //parent() - returns the index of the parent of index i
    private int parent(int i) {
        return (i - 1) / 2;
    }

    //clear() - clears the Heap (clears the ArrayList)
    public void clear() {
        heapVals.clear();
    }

    //size() - returns the size of the heap
    public int size() {
        return heapVals.size();
    }

    //isEmpty() - returns whether or not the heap is empty
    public boolean isEmpty() {
        if (heapVals.size() == 0) {
            return true;
        } else {
            return false;
        }
    }

    //toString() - returns a String containing all the items in the CS2Heap in level-order
    public String toString() {
        return toString(0, 0);
    }

    private String toString(int index, int level) {
        String right = "";
        String left = "";
        String middle = "";
        if (isEmpty()) {
            return "Empty List";
        }
        if (index >= heapVals.size()) {
            return "";
        } else {
            for (int i = 0; i < level; i++) {
                middle += "-";
            }
            right = toString(rightChild(index), level + 1) + '\n';
            middle += heapVals.get(index);
            left = toString(leftChild(index), level + 1);
        }
        return right + middle + left;
    }
}
