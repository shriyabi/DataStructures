package cs2.heap;

public class Patient implements Comparable<Patient> {
    // constants for use with Patient object

    public static final int ASC = 0;    // ascending/descending sort
    public static final int DESC = 1;

    public static final int BY_NAME = 0;    //  name/condition priority
    public static final int BY_CONDITION = 1;

    private static int dir = Patient.ASC;   // default ascending
    private static int sortBy = Patient.BY_CONDITION;   // default by condition

    private String name;
    private int condition;
    private long time = 0;

    public Patient(String name, int condition){
        this.name = name;
        this.condition = condition;
        time = System.nanoTime();
    }

    public int getCondition() {
        return condition;
    }

    public String getName() {
        return name;
    }

    public int compareTo(Patient other) {
        int compFactor;
        if (Patient.sortBy == Patient.BY_NAME) {
            compFactor = this.name.compareTo(other.name);
            if(compFactor == 0){
                compFactor = Long.compare(this.time, other.time);
            }
        }
        else {
            compFactor = this.condition - other.condition;
        }

        if (Patient.dir == Patient.ASC) {
            return compFactor;
        }
        else {
            return -1 * compFactor;
        }
    }

    public String toString(){
        if (Patient.sortBy == Patient.BY_NAME)
            return ("Name: " + name + "; Condition Level: "+ condition);
        else
            return ("Condition Level: " + condition + "; Name: " + name);
    }

    public static void setDirection(int direc){
        Patient.dir = direc;
    }
    public static void sortBy(int key){
        Patient.sortBy = key;
    }
}

