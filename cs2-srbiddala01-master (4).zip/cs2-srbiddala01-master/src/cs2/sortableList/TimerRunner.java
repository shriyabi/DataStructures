package cs2.sortableList;

public class TimerRunner {
    public static void main (String[] args) {
        SortableList<Integer> selection;

        // perform "warm-up" - create/fill SortableList
        for(int s = 0; s < 1000; s++){
            selection = new SortableList<>();
            //fill with random values
            for(int i = 0; i < 10000; i++){
                selection.add((int)(Math.random() * 100));
            }
        }

        // vary n (list size) for the x axis value
        for (int n = 1000; n < 10000; n += 500) {

            // create a new list
            selection = new SortableList<>();

            // fill with random values
            for (int i = 0; i < n; i++) {
                selection.add((int) (Math.random() * n));
            }

            // time Selection Sort for a list of size n
            System.gc();
            SortableList<Integer> bubble = (SortableList<Integer>)selection.clone();
            SortableList<Integer> insertion = (SortableList<Integer>)selection.clone();
            SortableList<Integer> merge = (SortableList<Integer>)selection.clone();
            SortableList<Integer> gnome = (SortableList<Integer>)selection.clone();

            long start = System.nanoTime();
            selection.selectionSort();
            long end = System.nanoTime();

            long start1 = System.nanoTime();
            bubble.bubbleSort();;
            long end1 = System.nanoTime();

            long start2 = System.nanoTime();
            insertion.insertionSort();
            long end2 = System.nanoTime();

            long start3 = System.nanoTime();
            merge.mergeSort();
            long end3 = System.nanoTime();

            long start4 = System.nanoTime();
            gnome.gnomeSort();
            long end4 = System.nanoTime();



            // print n and elapsed time to console (separate with a tab so
            //  you can copy/paste into a Google Sheet
            System.out.println(n + "\t" + (end - start) + "\t" + (end1 - start1) + "\t" + (end2 - start2) + "\t" + (end3 - start3)+ "\t" + (end4 - start4));
        }
    }
}




