package cs2.maze;

// Prevent teleporting.

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.util.ArrayList;
import java.util.Stack;

//My final code is here... I thought I pushed it to GitHub
public class Mouse extends Actor {
    public Mouse(){
        this.setColor(null);
    }

    private Stack<Location> locationHolder = new Stack<>();
    private boolean foundCheeseAndGameOver = false;

    public void act() {
        Grid<Actor> gr = this.getGrid();
        Location loc = this.getLocation();
        while (!foundCheeseAndGameOver) {
            if (findCheese() == null) {
                ArrayList<Location> locs = getLocs(loc);
                if (locs.size() != 0) {
                    for (int i = 0; i < locs.size(); i++) {
                        locationHolder.push(locs.get(i));
                    }
                }
            }
            for(int j = 0; j < locationHolder.size(); j++){
                loc = locationHolder.pop();
                ArrayList<Location> locations = getLocs(loc);
                if (locations.size() == 0 ){
                    continue;
                }
                locationHolder.push(loc);
                for(int i = 0; i < locations.size(); i++){
                    locationHolder.push(locations.get(i));
                }
                if (foundCheeseAndGameOver) {
                    this.moveTo(locationHolder.pop());
                    locationHolder.push(this.getLocation());
                    while (locationHolder.size() != 0) {
                        locationHolder.pop();
                        Candy trailMarker = new Candy();
                        trailMarker.putSelfInGrid(gr, loc);
                    }
                }
            }
        }
    }

    private Location findCheese(){
        Grid<Actor> gr = this.getGrid();
        Location loc = this.getLocation();
        Cheese cheeseObj = new Cheese();
        if(gr.isValid(loc.getAdjacentLocation(0)) && gr.get(loc.getAdjacentLocation(0)) instanceof Cheese) {
            //north
            loc = loc.getAdjacentLocation(0);
            cheeseObj.removeSelfFromGrid();
        } else if(gr.isValid(loc.getAdjacentLocation(90)) && gr.get(loc.getAdjacentLocation(90)) instanceof Cheese) {
            //east
            loc = loc.getAdjacentLocation(90);
            cheeseObj.removeSelfFromGrid();
        } else if(gr.isValid(loc.getAdjacentLocation(180)) && gr.get(loc.getAdjacentLocation(180)) instanceof Cheese){
            //south
            loc = loc.getAdjacentLocation(180);
            cheeseObj.removeSelfFromGrid();
        } else if(gr.isValid(loc.getAdjacentLocation(270)) && gr.get(loc.getAdjacentLocation(270)) instanceof Cheese){
            //west
            loc = loc.getAdjacentLocation(270);
            cheeseObj.removeSelfFromGrid();
        } else {
            loc = null;
        }
        if(loc != null){
            System.out.println("Game Over! You won!");
            foundCheeseAndGameOver = true;
        }
        return loc;
    }

    private ArrayList<Location> getLocs(Location loc){
        ArrayList<Location> locs = new ArrayList<Location>();
        Grid<Actor> gr = this.getGrid();
        while (gr.get(loc) != null) {
            if ((gr.get(loc.getAdjacentLocation(0)) instanceof Cheese) || (gr.isValid(loc.getAdjacentLocation(0)) && gr.get(loc.getAdjacentLocation(0)) == null) ) {
                loc = loc.getAdjacentLocation(0);
                locs.add(loc);
            } else if ((gr.get(loc.getAdjacentLocation(90)) instanceof Cheese) || (gr.isValid(loc.getAdjacentLocation(90)) && gr.get(loc.getAdjacentLocation(90)) == null)) {
                loc = loc.getAdjacentLocation(90);
                locs.add(loc);
            } else if ((gr.get(loc.getAdjacentLocation(0)) instanceof Cheese) || (gr.isValid(loc.getAdjacentLocation(180)) && gr.get(loc.getAdjacentLocation(180)) == null)) {
                loc = loc.getAdjacentLocation(180);
                locs.add(loc);
            } else if ((gr.get(loc.getAdjacentLocation(0)) instanceof Cheese) ||(gr.isValid(loc.getAdjacentLocation(270)) && gr.get(loc.getAdjacentLocation(270)) == null)) {
                loc = loc.getAdjacentLocation(270);
                locs.add(loc);
            } else {
                break;
            }
            if (gr.get(loc) instanceof Cheese) {
                foundCheeseAndGameOver = true;
                return locs;
            }
            if (loc != null) {
                Breadcrumb breadcrumb = new Breadcrumb();
                breadcrumb.putSelfInGrid(gr, loc);
            }
        }
        return locs;
    }
}
