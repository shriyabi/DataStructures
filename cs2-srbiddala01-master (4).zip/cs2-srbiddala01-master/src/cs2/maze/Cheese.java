package cs2.maze;

import info.gridworld.actor.Rock;

public class Cheese extends Rock {
    public Cheese(){
        this.setColor(null);
    }
}
