package cs2.maze;

import info.gridworld.actor.Actor;

public class Candy extends Actor {
    public Candy(){
        this.setColor(null);
    }
}

